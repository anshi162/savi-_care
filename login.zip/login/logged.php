<?php 

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: index.php");
}

?>

<!DOCTYPE html>
<html> 
  <head>
      <title>Savi-Care</title> 
      <link href="slider.css" rel="stylesheet">
      <link href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.min.css" rel="stylesheet" type="text/css" />

<style type="text/css">
   .wel{
     font-size: 30px;
     text-align: right;
      color: #0000FF;
     
   }
   img.img1{
    margin-left:320px;
    margin-top:40px;
    height:250px;
    width:250px;
    
   }
  
   
   img.img2 {
  margin-left:50px;
  margin-top:40px;
  height:250px;
  width:250px;
  }
  img.img3 {
  margin-left:50px;
  margin-top:40px;
  height:250px;
  width:250px;
  }
  p.l1{
    margin-top: 50px;
    margin-left: 220px;
    }
   p.l2{
    margin-top: 1px;
    margin-left: 220px;
    }
   img.den{
    margin-left: 220px;
    height:200px;
    width:250px;
    }
   img.gyn{
    margin-left: 50px;
    height:200px;
    width:250px;
    }
   img.diet{
    margin-left: 50px;
    height:200px;
    width:250px;
    }
   img.phy{
    margin-left: 50px;
    height:200px;
    width:250px;
    margin-right: 50px;
    }
    img.physi{
    margin-left: 50px;
    height:200px;
    width:250px;
    margin-right: 50px;
    }
    img.sur{
    margin-left: 50px;
    height:200px;
    width:250px;
    margin-right: 50px;
    }
    img.ped{
    margin-left: 50px;
    height:200px;
    width:250px;
    margin-right: 50px;
    }
    img.ortho{
    margin-left: 50px;
    height:200px;
    width:250px;
    margin-right: 50px;
    }
    img.gas{
    margin-left: 50px;
    height:200px;
    width:250px;
    margin-right: 50px;
    }

  </style>     
</head>
  

<body style="background-color:rgb(235, 244, 245);"  >
     <font align="left" size=5><a href="logout.php">Logout</a></font>
     <U><div class=wel><?php echo "Welcome, " . $_SESSION['username'] . ""; ?></div></U>
     <center><I><B><font size=7 color="teal" face="Cooper black">Savi-Care</font></B></I></center>
     <center><B><font size=3 color="black" face="Albertus">Your health matters</font></B></center>
     
     <HR size=2 noshade width=75%>
     
        <BR><BR>
    <center> <img src="image_1.jpg" width="1050" height="250"></center>
    <BR><BR>
       
      <img src="img.png" class="img1" >
       <a href="https://www.netmeds.com/"><img src="img1.png" class="img2" ></a>
       <img src="img2.png" class="img3" >

       
      <p class="l1" >
      <B><font size=6 color="black" face="arial rounded mt bold">Book an appointment for an in-clinic consultation</font></B>
      </p>
      <p class="l2" >
        <B><font size=4 color="black" face="candara light">Find experienced doctors across all specialties</font></B>
     </p>
    <BR>
      <div class="slide">
        <img src="dentist.png" class="den">  
        <img src="gynac.png" class="gyn">  
        <img src="diet.png" class="diet"> 
        <img src="physio.png" class="phy"> 
        <img src="physi.png" class="physi"> 
        <img src="sur.png" class="sur"> 
        <img src="pedia.png" class="ped">
        <img src="ortho.png" class="ortho">  
        <img src="gastro.png" class="gas"> 

        
        </div>
        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.min.js" type="text/javascript"></script>
        <script type="text/javascript">
           $('.slide').slick({
            infinite: false,
            slidesToShow: 3,
             slidesToScroll: 3
          });
       </script>
   
</body>
    
</html>